import pygame
import os
import time as t
import random as r
Player_record_1 = 0
Player_record_2 = 0
x = 1
while x < 3:





    def setting(path,xpos,ypos):
        name = pygame.image.load(path)
        name_size = name.get_rect().size 
        name_width = name_size[0]
        name_height = name_size[1]
        name_x_pos = xpos
        name_y_pos = ypos

        return name,name_size,name_width,name_height,name_x_pos, name_y_pos


    path = os.getcwd()
    pygame.init()
    screen_width = 500
    screen_height = 1000
    screen = pygame.display.set_mode((screen_width,screen_height))

    bg_path = os.path.join(path, "background.png")
    character_path = os.path.join(path, "Player.png")
    mul_path = os.path.join(path, "sm_mul.png")
    mul_2_path = os.path.join(path, "mi_mul.png")
    mul_3_path = os.path.join(path, "bi_mul.png")
    mul_4_path = os.path.join(path, "sm_mul.png")
    mul_5_path = os.path.join(path, "mi_mul.png")
    mul_6_path = os.path.join(path, "bi_mul.png")
    mul_7_path = os.path.join(path, "sm_mul.png")

    background = pygame.image.load(bg_path)

    c,c_size,c_width,c_height,c_xpos,c_ypos = setting(character_path,10,700)

    m,m_size,m_width,m_height,m_xpos,m_ypos = setting(mul_path,100,100)

    m_2,m_2_size,m_2_width,m_2_height,m_2_xpos,m_2_ypos = setting(mul_2_path,200,100)

    m_3,m_3_size,m_3_width,m_3_height,m_3_xpos,m_3_ypos = setting(mul_3_path,300,100)

    m_4,m_4_size,m_4_width,m_4_height,m_4_xpos,m_4_ypos = setting(mul_4_path,200,100)

    m_5,m_5_size,m_5_width,m_5_height,m_5_xpos,m_5_ypos = setting(mul_5_path,300,100)

    m_6,m_6_size,m_6_width,m_6_height,m_6_xpos,m_6_ypos = setting(mul_6_path,300,100)
    m_7,m_7_size,m_7_width,m_7_height,m_7_xpos,m_7_ypos = setting(mul_7_path,200,100)


    pygame.display.set_caption("비 피하기 게임")

    to_x = 0
    to_y = 0

    to_x_2 = 0
    to_y_2 = 0

    clock = pygame.time.Clock()

    player_speed = 3
    speed = 0.7

    game_font = pygame.font.Font(None, 40)

    total_time = 120

    start_ticks = pygame.time.get_ticks()




    running = True

    winning = 0




    m_xpos = r.randrange(0,420)
    m_2_xpos = r.randrange(0,420)
    m_3_xpos = r.randrange(0,420)
    m_4_xpos = r.randrange(0,420)
    m_5_xpos = r.randrange(0,420)
    m_6_xpos = r.randrange(0,420)
    m_7_xpos = r.randrange(0,420)


    m_ypos = r.randrange(0,150)
    m_2_ypos = r.randrange(0,150)
    m_3_ypos = r.randrange(0,150)
    m_4_ypos = r.randrange(0,150)
    m_5_ypos = r.randrange(0,150)
    m_6_ypos = r.randrange(0,150)
    m_7_ypos = r.randrange(0,150)



    mspeed = 2





    running = True
    life = 180
    while running:
        dt = clock.tick(60)
        print(life)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    to_x -= player_speed
                elif event.key == pygame.K_RIGHT:
                    to_x += player_speed

            if event.type==pygame.KEYUP:
                if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                    to_x = 0
                elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                    to_y = 0


            
            


            
            
        mspeed += 0.001

        c_xpos += to_x

        m_ypos += mspeed
        m_2_ypos += mspeed
        m_3_ypos += mspeed
        m_4_ypos += mspeed
        m_5_ypos += mspeed
        m_6_ypos += mspeed
        m_7_ypos += mspeed

            
            

        if c_xpos < 0:
            c_xpos = 0

        elif c_xpos > screen_width - c_width:
            c_xpos = screen_width - c_width
            
        if m_ypos > 1000:
            m_ypos = -100
            m_xpos = r.randrange(0,420)

        if m_2_ypos > 1000:
            m_2_ypos = -100
            m_2_xpos = r.randrange(0,420)
        if m_3_ypos > 1000:
            m_3_ypos = -100
            m_3_xpos = r.randrange(0,420)
        if m_4_ypos > 1000:
            m_4_ypos = -100
            m_4_xpos = r.randrange(0,420)
        if m_5_ypos > 1000:
            m_5_ypos = -100
            m_5_xpos = r.randrange(0,420)
        if m_6_ypos > 1000:
            m_6_ypos = -100
            m_6_xpos = r.randrange(0,420)
        if m_7_ypos > 1000:
            m_7_ypos = -100
            m_7_xpos = r.randrange(0,420)

        c_rect = c.get_rect()
        c_rect.left = c_xpos
        c_rect.top = c_ypos


        m_rect = m.get_rect()
        m_rect.left = m_xpos
        m_rect.top = m_ypos

        m_2_rect = m_2.get_rect()
        m_2_rect.left = m_2_xpos
        m_2_rect.top = m_2_ypos
        m_3_rect = m_3.get_rect()
        m_3_rect.left = m_3_xpos
        m_3_rect.top = m_3_ypos
        m_4_rect = m_4.get_rect()
        m_4_rect.left = m_4_xpos
        m_4_rect.top = m_4_ypos
        m_5_rect = m_5.get_rect()
        m_5_rect.left = m_5_xpos
        m_5_rect.top = m_5_ypos
        m_6_rect = m_6.get_rect()
        m_6_rect.left = m_6_xpos
        m_6_rect.top = m_6_ypos
        m_7_rect = m_7.get_rect()
        m_7_rect.left = m_7_xpos
        m_7_rect.top = m_7_ypos
        
        if c_rect.colliderect(m_rect):
            
            running = False
        if c_rect.colliderect(m_2_rect):
            running = False
        if c_rect.colliderect(m_3_rect):
            running = False
        if c_rect.colliderect(m_4_rect):
            running = False
        if c_rect.colliderect(m_5_rect):
            running = False
        if c_rect.colliderect(m_6_rect):
            running = False
        if c_rect.colliderect(m_7_rect):
            running = False


            



        screen.blit(background, (0,0))

        screen.blit(c, (c_xpos,c_ypos))
        screen.blit(m, (m_xpos,m_ypos))
        screen.blit(m_2, (m_2_xpos,m_2_ypos))
        screen.blit(m_3, (m_3_xpos,m_3_ypos))
        screen.blit(m_4, (m_4_xpos,m_4_ypos))
        screen.blit(m_5, (m_5_xpos,m_5_ypos))
        screen.blit(m_6, (m_6_xpos,m_6_ypos))
        screen.blit(m_7, (m_7_xpos,m_7_ypos))

            

        elapsed_time = (pygame.time.get_ticks() - start_ticks) / 1000
        timer = game_font.render(str(int(elapsed_time)), True, (255,255,255))
        screen.blit(timer, (0,200))

        pygame.display.update()

    if x == 1:
        Player_record_1 = elapsed_time
    elif x == 2:
        Player_record_2 = elapsed_time

    x += 1
    t.sleep(3)


    
if Player_record_1 > Player_record_2:
    print("Winner :Player_record_1")
else :
    print("Winner : Player_record_2")
print("차이 : ",max(Player_record_1,Player_record_2) - min(Player_record_1,Player_record_2))

pygame.quit()

t.sleep(3)

# 37.587
# 41.805